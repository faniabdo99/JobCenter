<?php
return [
  'PageTitle' => 'Blog',
  'BlogCategories' => 'Blog Categories',
  'Attachments' => 'Attachments',
  'Comments' => 'Comments',
  'Comment' => 'Comment',
  'ToAddComment' => 'To Add Comment',
  'LeaveComment' => 'Leave Comment'
];
