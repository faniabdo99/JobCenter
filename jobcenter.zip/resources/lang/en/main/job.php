<?php
return [
  'JobOverview' => 'Job Overview',
  'DatePosted' => 'Date Posted',
  'JobPosition' => 'Job Position',
  'JobMinAge' => 'Minimum Age',
  'JobSalary' => 'Salary',
  'JobSalaryAfterMeeting' => 'After Meeting',
  'JobLoginToApply' => 'Login to Apply !',
  'JobApplyNow' => 'Apply Now !',
  'JobApplyH' => 'Apply For This Job',
  'JobJobDesc' => 'Job Description',
  'JobResponse' => 'Responsibilities',
  'JobCriteria' => 'Criteria',
  'JobRelatedJobs' => 'Related Jobs',
];
