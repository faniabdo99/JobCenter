<?php
return [
  'JobsH' => 'Jobs',
  'JobsByCategory' => 'Jobs By Category',
  'ViewAllCategories' => 'View All Categories',
  'JobsByLocation' => 'Jobs By Location',
];
