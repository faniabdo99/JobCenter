<?php
return [
  'JobsByCategory' => 'Jobs By Category',
];
