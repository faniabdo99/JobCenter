<?php
return [
  'IndexTopH' => 'The Easy Way To Get Your New Job',
  'IndexTopP' => 'Search for a specific job by writing the location, type and Category for the jobs',
  'IndexBrowseByCategoryH' => 'Browse Jobs By Category',
  'IndexBrowseByCategoryP' => 'Choose the Category that fits you',
  'IndexFromBlogH' => 'from our blog',
  'IndexFromBlogP' => 'Our Latest News and Events',
  'IndexFeedbackH' => 'feed back',
  'IndexFeedbackP' => 'we would love to hear your thoughts, concerns, or problems with anything so we can improve.',
  'IndexFAQ' => 'Frequently Asked Question?'

];
