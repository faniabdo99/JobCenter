<?php
return [
  'CompanyProfile' => 'Company Profile',
  'CompanyOverview' => 'Company Overview',
  'DownloadProfile' => 'Download Profile',
];
