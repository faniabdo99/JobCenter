<?php
return [
  'AboutDesc' => 'Over the past 30 years, armed conflicts and sectarian violence have ravaged Iraq. Hundreds of thousands of casualties left the widowed women to be the breadwinner for the family. In this context, especially in the southern
                  area of Iraq, many young females and children dropped out of school.<br>
                   Illiterate women are estimated to be 26.4% comparing with men which reached up to 11.6%. The illiteracy is a main factor for pushing women to early
                  marriage or following negative coping strategies like begging.',
    'OurGoals' => 'Our Goal',
    'OurGoalsP' => '<li>Decrease the unemployment rate.</li>
                    <li>Promote gender equality / equity.</li>
                    <li>Enhance the capacity of the females to get better job opportunities.</li>
                    <li>Contribute to improve the image of women / female jobseekers</li>
                    <li>Contribute to female networking and exchange.</li>
                    <li>Increasing female participation in the local job market.</li>
                    <li>Boost female self-confidence and raise awareness for the opportunities provided on the local labour market.</li>',
    'Vision' => 'Vision',
    'VisionP' => 'We work on supporting the hiring opportunities for the trainees to match their skills with the required job skills.',
    'Mission' => 'Mission',
    'MissionP1' => 'We build up females capacities and skills to acquire more job opportunities and then we do job matching between the available jobs at the jobs’ market and the female candidates in our databases.',
    'MissionP2' => 'Today, we were able to train a big number of females in job readiness topics, and we have built up a data base of female candidates with different professions and backgrounds. We are a free of charge job center and happy to offer our services to the different employment sectors in Basra and Iraq.'
];
