<?php
return [
  'SearchPH' => 'Enter Search Query Here',
  'SearchH' => 'Search'
];
