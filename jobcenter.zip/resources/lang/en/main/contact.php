<?php
return [
  'ContactUsH' => 'Contact Us',
  'ContactUsH2' => 'Get In Touch',
  'ContactUsP1' => 'We are here to Help you!',
  'ContactUsP2' => 'We would love to hear your thoughts, concerns, or problems with anything so we can improve.',
];
