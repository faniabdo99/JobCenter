<?php
return [
  'AppName' => 'Women Job Center',
  'Address' => 'Iraq, Basra, Aljubaila Quarter, Dinar St, Opposite to Alasad Station, on the top of Blateen fashon shop',
];
