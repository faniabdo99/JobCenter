<?php
return [
  'ImplementedBy' => 'Implemented By',
  'Register' => 'Register',
  'Pages' => 'Pages',
  'Alkarnak' => 'Al Karnak',
  'AllRightsR' => 'All Rights Reserved.',
  'Address' => 'Iraq, Basra, Aljubaila Quarter, Dinar St, Opposite to Alasad Station, on the top of Blateen fashon shop'
];
