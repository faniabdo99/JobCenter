<?php
return [
  'IndexSearchQuery' => 'Keyword e.g. (Job Title, Description, Tags)',
  'NamePH' => 'Your Name',
  'EmailPH' => 'Your Email',
  'PhonePH' => 'Your Phone Number',
  'MessagePH' => 'Your Message',
  'ResumeL' => 'Resume',
  'ResumeI' => 'Upload Resume',
  'ResumeLimits' => 'Microsoft Word or PDF Files Only',
  'Submit' => 'Submit'
];
