<?php
return [
  'AboutUs' => 'About Us',
  'Categories' => 'Categories',
  'Companies' => 'Companies',
  'ContactUs' => 'Contact Us',
  'Jobs' => 'Jobs',
  'Search' => 'Search'
];
