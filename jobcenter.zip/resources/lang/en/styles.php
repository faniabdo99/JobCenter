<?php
return [
  'TextAlign' => 'text-left',
  'Direction' => 'ltr',
];
