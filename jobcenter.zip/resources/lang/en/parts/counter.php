<?php
return [
  'CounterH' => 'Some Statistical Facts'
];
