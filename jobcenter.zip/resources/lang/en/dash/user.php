<?php
return [
    //User Sidebar
    'Dashboard' => 'dashboard',
    'EditProfile' => 'edit profile',
    'Resume' => 'resume',
    'Favourite' => 'favourite',
    'AppliedJobS' => 'applied jobs',
    'LogOut' => 'Log out',
    //User Applications
    'CandidateAppliedJobs' => 'Candidate Applied Jobs',
    'Delete' => 'Delete',
    //User editblade
    'ProfileImageJPEGorPNG' => 'Profile Image JPEG or PNG',
    'BrowseImage' => 'browse image',
    'Name' => 'name',
    'Resume' => 'Resume (PDF)',
    'Phone' => 'Phone',
    'Website' => 'Website',
    'Category' => 'category',
    'NoData' => 'No Data',
    'Address' => 'address',
    'City' => 'city',
    'NoData' => 'No Data',
    'Description' => 'Description',
    'SocialNetworks' => ' social networks',
    'Instagram' => 'Instagram',
    'Facebook' => 'facebook',
    'Twitter' => 'twitter',
    'Linkedin' => 'linkedin',
    'UpdatePassword' => 'update password',
    'CurrentPassword' => 'current password',
    'NewPassword' => 'new password',
    'SaveChanges' => 'save changes',
      //User favesblade
      'FavouriteJobs' => 'Favourite Jobs',
      'Favourite' => 'favourite',
      'IQD/Month' => 'IQD/Month',
      'LookingForAJob' => 'Looking For A Job',
      'YourNextLevelProductDevelopemntCompanyAssetsYourNextLevelProduct' => 'Your next level Product developemnt company assetsYour next level Product',
      'Submit' => 'submit',
      //User indexblade
      'Dashboard' => 'Dashboard',
      'BasicInformation' => 'basic information',
      'JobDescription:' => 'job description:',
      'Location:' => 'Location:',
      'Phone:' => 'phone:',
      'Email:' => 'email:',
      'Website:' => 'website:',
      'SocialProfile' => 'social profile',
      'AppliedJobs' => 'applied jobs',
      'FavouriteJobs' => 'favourite jobs',
      'LookingForAJob' => 'Looking For A Job',
      //User profile blade
      'BasicInformation' => 'basic information',
      'JobCategory:' => 'job category:',
     'Location:' => 'Location:',
     'Phone' => 'phone:',
     'Email' => 'email:',
     'Website' => 'website:',
     'Description' => 'description:',
     'SocialProfile' => 'social profile',
     'DontHaveACVUploaded' => 'Dont Have a CV Uploaded',
       //resume blade
       'CandidatesResume' => 'Candidates resume',
       'Home' => 'Home',
       'Dashboard' => 'Dashboard',
       'PleaseUploadYouCVToSeeItHere' => 'Please Upload You CV to See it Here',
       'LookingForAJob' => 'Looking For A Job',
       'Submit' => 'submit',





];
