<?php
return [
  //APPLICATION NOT
  'NewJobApplicationInJobCenter' => 'New Job Application in Job Center',
  'YouHaveNewJobApplication' => 'You Have New Job Application',
  'ApplicationDetails' => 'Application Details',
  'JobTitle' => 'Job Title',
  'Candidate' => 'Candidate',
  'ApplicationMessage' => 'Application Message',
  'GetTheFullApplicationDetailsFromYourApplicationsPage' => 'Get the full application details from your applications page!',
  'ViewProfile' => 'View Profile',
  'ApplicationsList' => 'Applications List',
  'Thanks' => 'Thanks',
  //contactus
  'NewMailFromJobCenter' => 'New Mail From Job Center',
  'From' => 'From',
  //contact
   'NewMailFromJobCenter' => 'New Mail From Job Center',
   'From' => 'From',
   //quickcontact
   'NewEmail' => 'New Email',
   'YouRecivedThisEmailFromWomenJobCenterHomePage' => 'You recived this email from Women Job Center Home page.',
   'MessageTitle:' => 'Message Title :',
   'UserEmail:' => 'User Email :',
   'UserName:' => 'user Name :',
   'Thanks' => 'Thanks',
   //reset Password
   'ResetPassword' => 'Reset Password',
   'Hello' => 'Hello ,',
   'YouHaveRequstedAPasswordResetToYourJobCenterAccount' => 'You have requsted a password reset to your job center account , please click thr button below to reset your password.',
   'ResetPassword' => 'Reset Password',
   'IfYouDidntMadeThisRequsteDontWorryJustIgnoreThisEmailAndYourPasswordWontBeChanged' => 'if you didnt made this requste dont worry , just ignore this email and your password wont be changed.',
   'Thanks' => 'Thanks',
   //user blade
   'Welcome' => 'Welcome',
   'HelloThere' => 'Hello There',
   'WelcomeToJobCenterPortal' => 'Welcome to Job Center Portal.',
   'YouHaveCreatedNewAccountWithThisEmailAndWeNeedYouToVerfiyItPleaseClickTheLinkBelowToVerifyYourAccount' => 'You have created new account with this email , and we need you to verfiy it, please click the link below
   to verify your account.',
   'WelcomeToTheSite' => 'Welcome to Women Job Center ! Thank You For Choosing Us!',
   'ActivateAccount' => 'Activate Account',
   'Thanks' => 'Thanks,',
];
