<?php
return [
  'IndexSearchQuery' => 'كلمات دلالية مثل (المسمى الوظيفي والوصف والعلامات)',
  'NamePH' => 'الاسم',
  'EmailPH' => 'البريد الالكتروني',
  'PhonePH' => 'رقم الهاتف',
  'MessagePH' => 'الرسالة',
  'ResumeL' => 'السيرة الذاتية',
  'ResumeI' => 'تحميل السيرة الذاتية',
  'ResumeLimits' => 'ملفات Microsoft Word أو PDF فقط',
  'Submit' => 'تقديم'
];
