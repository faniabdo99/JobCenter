<?php
return [
  'AboutUs' => 'من نحن',
  'Categories' => 'الفئات',
  'Companies' => 'الشركات',
  'ContactUs' => 'تواصل معنا',
  'Jobs' => 'الوظائف',
  'Search' => ' بحث '
];
