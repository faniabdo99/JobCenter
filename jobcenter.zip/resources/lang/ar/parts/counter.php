<?php
return [
  'CounterH' => 'بعض الاحصائيات عن موقعنا'
];
