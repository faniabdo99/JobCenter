<?php
return [
  'LookingFor' => 'هل تبحث عن ',
];
