<?php
return [
  'TextAlign' => 'text-right',
  'Direction' => 'rtl',
];
