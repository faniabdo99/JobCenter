<?php
return [
  'CompanyProfile' => 'الملف التعريفي للشركة',
  'CompanyOverview' => 'نظرة عامة',
  'DownloadProfile' => 'تحميل الملف التعريفي',
];
