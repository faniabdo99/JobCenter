<?php 

    return [
      'SignUp' => 'تسجيل ',
      'OR' => 'أو',
      'SignupWithFacebook' => 'تسجيل باستخدام فيسبوك',
      'SignupWithGoogle' => 'تسجيل باستخدام جوجل',
      'FullName' => 'الاسم',
      'Email' => 'البريد الالكتروني',
      'Password' => 'كلمة السر',
      'PasswordConfrim' => 'تأكيد كلمة السر',
      'ChooseAccountType' => 'اختار نوع الحساب',
      'CandidateAccount' => 'حساب مرشح',
      'CompanyAccount' => 'حساب شركة',
      'ForgetPassword' => 'نسيت كلمة المرور',
      'Login' => 'دخول',
      'AlreadyHaveAccount' => 'لديك حساب ؟',
      'LoginWithFacebook' => 'دخول باستخدام فيسبوك',
      'LoginWithGoogle' => 'دخول باستخدام جوجل',
      'NoAccount' => 'ليس لديك حساب ؟',
      'PasswordReset' => 'تغيير كلمة المرور',
      'ResetLink' => 'ارسال الرابط'
    ];