<?php
return [
  'SearchPH' => 'أدخل عبارة البحث هنا',
  'SearchH' => ' بحث '
];
