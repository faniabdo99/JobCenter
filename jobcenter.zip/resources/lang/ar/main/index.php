<?php
return [
  'IndexTopH' => 'الوسيلة الامثل للحصول على وظيفتك الجديدة',
  'IndexTopP' => 'ابحث عن وظيفة محددة عن طريق كتابة موقع  ونوع وفئة الوظيفة',
  'IndexBrowseByCategoryH' => 'تصفح الوظائف حسب الفئة',
  'IndexBrowseByCategoryP' => 'اختر الفئة التي تناسبك',
  'IndexFromBlogH' => 'من مدونتنا',
  'IndexFromBlogP' => 'آخر الأخبار والأحداث',
  'IndexFeedbackH' => 'ردود الفعل',
  'IndexFeedbackP' => 'نرغب بسماع أفكاركم ومقترحاتكم ليتسنى لنا تطوير الموقع الى الافضل.',
  'IndexFAQ' => 'الرسائل المتكررة؟'
];
