<?php
return [
  'IndexTopH' => 'الطريقة السهلة للحصول على عمل !',
  'IndexTopP' => 'Search for a specific job by writing the location, type and Category for the jobs',
  'IndexBrowseByCategoryH' => 'الأقسام',
  'IndexBrowseByCategoryP' => 'Choose the Category that fits you',
  'IndexFromBlogH' => 'من المدونة',
  'IndexFromBlogP' => 'Our Latest News and Events',
  'IndexFeedbackH' => 'مراجعاتكم',
  'IndexFeedbackP' => 'we would love to hear your thoughts, concerns, or problems with anything so we can improve.',
  'IndexFAQ' => 'Frequently Asked Question?'

];
