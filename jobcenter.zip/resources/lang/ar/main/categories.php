<?php
return [
  'JobsByCategory' => 'الوظائف حسب الفئة',
];
