<?php
return [
  'JobOverview' => 'ملخص الوظيفة',
  'DatePosted' => 'تاريخ النشر',
  'JobPosition' => 'المنصب الوظيفي',
  'JobMinAge' => 'الحد الإدنى للعمر',
  'JobSalary' => 'الراتب',
  'JobSalaryAfterMeeting' => 'بعد المقابلة',
  'JobLoginToApply' => 'تسجيل الدخول للتقديم',
  'JobApplyNow' => 'قدم الان!',
  'JobApplyH' => 'قدم على هذه الوظيفة',
  'JobJobDesc' => 'وصف الوظيفة',
  'JobResponse' => 'المسؤوليات والواجبات',
  'JobCriteria' => 'المعايير الوظيفية',
  'JobRelatedJobs' => 'وظائف ذات صلة',
];
