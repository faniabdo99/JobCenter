<?php
return [
  'JobsH' => 'الوظائف',
  'JobsByCategory' => 'الوظائف حسب الفئة',
  'ViewAllCategories' => 'عرض جميع الوظائف',
  'JobsByLocation' => 'الوظائف حسب الموقع الجغرافي',
];
