<?php
return [
  'PageTitle' => 'المدونة',
  'BlogCategories' => 'أقسام المدونة',
  'Attachments' => 'الملحقات',
  'Comments' => 'التعليقات',
  'Comment' => 'التعليق',
  'ToAddComment' => 'لإضافة تعليق',
  'LeaveComment' => 'اضافة تعليق'
];
