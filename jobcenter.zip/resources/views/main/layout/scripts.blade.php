    <!--custom js files-->
    <script src="{{url('public/main/js')}}/jquery-3.3.1.min.js"></script>
    <script src="{{url('public/main/js')}}/bootstrap.min.js"></script>
    <script src="{{url('public/main/js')}}/modernizr.js"></script>
    <script src="{{url('public/main/js')}}/jquery.menu-aim.js"></script>
    <script src="{{url('public/main/js')}}/plugin.js"></script>
    <script src="{{url('public/main/js')}}/owl.carousel.js"></script>
    <script src="{{url('public/main/js')}}/jquery-ui.js"></script>
    <script src="{{url('public/main/js')}}/jquery.countTo.js"></script>
    <script src="{{url('public/main/js')}}/jquery.magnific-popup.js"></script>
    <script src="{{url('public/main/js')}}/dropify.min.js"></script>
    <script src="{{url('public/main/js')}}/jquery.inview.min.js"></script>
    <script src="{{url('public/main/js')}}/jquery.nice-select.min.js"></script>
    <script src="{{url('public/main/js')}}/imagesloaded.pkgd.min.js"></script>
    <script src="{{url('public/main/js')}}/isotope.pkgd.min.js"></script>
    <script src="{{url('public/main/js')}}/custom.js"></script>
    <!-- custom js-->