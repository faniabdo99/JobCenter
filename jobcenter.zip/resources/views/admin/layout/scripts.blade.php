<script src="{{url('public/dash/js')}}/jquery-3.3.1.min.js"></script>
<script src="{{url('public/dash/js')}}/bootstrap.min.js"></script>
<script src="{{url('public/admin/js')}}/datatables.min.js"></script>
<script src="{{url('public/dash/js/tinymce')}}/jquery.tinymce.min.js"></script>
<script src="{{url('public/dash/js/tinymce')}}/tinymce.min.js"></script>
<script src="{{url('public/admin/js')}}/dropzone.js"></script>
<script type="text/javascript">
  $('#DataTable').DataTable();
</script>
